package com.Retos.CicloTres.repository.crud;

import com.Retos.CicloTres.model.Cabin;
import org.springframework.data.repository.CrudRepository;

public interface CabinCrudRepository extends CrudRepository<Cabin, Integer>{
    
}
